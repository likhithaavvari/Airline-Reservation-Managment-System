package in.co.air.line.ticket.bean;

/**
 * DropdownListBean Interface has Abstract Method
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
